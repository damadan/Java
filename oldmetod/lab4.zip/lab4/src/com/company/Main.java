package com.company;

import javax.swing.*;

public class Main extends JFrame {
    public static void main(String[] args) {
        new matchResults().setVisible(true);
    }
}